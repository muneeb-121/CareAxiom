let IndexController = require('../controller/getRestaurantsController');
let MakeReservationController = require('../controller/reservationController');
let ViewReservationsController = require('../controller/viewReservationsController'); 
let CancelReservationController = require('../controller/cancelReservationController');

module.exports = function(app){
    app.get('/',IndexController.renderResturants);
    app.post('/makeReservation',MakeReservationController.makeReservation);
    app.get('/viewReservations/:userid',ViewReservationsController.viewAll);
    app.get('/cancelReservation/:id',CancelReservationController.cancelReservation);
}

