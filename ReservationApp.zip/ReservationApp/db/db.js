var mysql = require('mysql');

var con = mysql.createConnection({
    host: "db4free.net",
    user: "muneeb",
    password: "muneeb7626"
  });
  con.connect(function(err) {
    if (err) throw err;
  });
  module.exports = con;