let con = require("../db/db");
let mysql = require('mysql');
let viewReservationController = require('../controller/viewReservationsController'); 

exports.cancelReservation = (req,res)=>{
    let id = req.params.id;
    
    con.query("UPDATE careaxiom_testdb.reservations SET status='Cancelled' WHERE id = ?",[id],function (err, result, fields) {
        if (err) throw err;
        res.send('succes');
    });

}