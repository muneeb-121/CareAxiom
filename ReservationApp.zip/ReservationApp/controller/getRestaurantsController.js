var con = require("../db/db");


exports.renderResturants = (req,res)=>{
  con.query("SELECT * FROM careaxiom_testdb.restaurants", function (err, result, fields) {
    if (err) throw err;
    res.render('index',{restaurantList:result});
  });
    
}