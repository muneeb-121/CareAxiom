let con = require("../db/db");
let mysql = require('mysql');

exports.viewAll = (req,res)=>{

    getAllReservations(req.params.userid).then((reservations)=>{
        res.render('viewAll',{reservations:reservations});
    })
}
function getAllReservations(userid){
    return new Promise((resolve,reject)=>{

        var query = "SELECT * FROM careaxiom_testdb.reservations where status='Reserved' AND userid=" + mysql.escape(userid);
        con.query(query,(err, result)=>{
          // if any error while executing above query, throw error
          if (err){
            return reject(err);
          }
          resolve(result);
    
          
        });

    });
}