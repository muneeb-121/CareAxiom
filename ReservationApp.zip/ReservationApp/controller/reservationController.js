var con = require("../db/db");
exports.makeReservation = (req,res)=>{
    var record = [[req.body.restaurantName,req.body.numberOfPersons,req.body.dateAndTime,req.body.userid]];
    con.query("INSERT INTO careaxiom_testdb.reservations(restaurantName, numberOfPersons, dateAndTime, userid) VALUES ?", [record], function (err, result, fields) {
      if (err){
        res.send({message:"false"});

      }
      else{
        res.send({message:"true"});
      }
      
    });
  }